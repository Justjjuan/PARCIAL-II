#include "estructuras.h"
#include <iostream>
#include <vector>
using namespace std;

int siguienteIdCarrito = 1;

int generarIdCarrito() {
    return siguienteIdCarrito++;
}

void adicionarProductoAlCarrito(CarritoDeCompras& carrito, Producto& producto, int cantidad) {
    if (producto.cantidadDisponible >= cantidad) {
        carrito.items[carrito.cantidadItems++] = {producto, cantidad};
        producto.cantidadDisponible -= cantidad;
        cout << "Producto agregado al carrito.\n";
    } else {
        cout << "No hay suficiente stock.\n";
    }
}

void listarProductosDelCarrito(CarritoDeCompras& carrito) {
    cout << "\n--- Carrito de Compras ---\n";
    float total = 0;
    for (int i = 0; i < carrito.cantidadItems; i++) {
        auto item = carrito.items[i];
        cout << item.producto.nombre << " x" << item.cantidad
             << " = $" << item.producto.valorUnitario * item.cantidad << endl;
        total += item.producto.valorUnitario * item.cantidad;
    }
    cout << "Total a pagar: $" << total << endl;
}
