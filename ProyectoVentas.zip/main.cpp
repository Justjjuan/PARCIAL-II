#include "estructuras.h"
#include <iostream>
#include <vector>
using namespace std;

vector<Usuario> inicializarUsuarios();
vector<Producto> inicializarProductos();
vector<Comentario> inicializarComentarios();
string iniciarSesion(vector<Usuario>& usuarios);
void listarUsuarios(vector<Usuario>& usuarios);
void listarProductosBajoStock(vector<Producto>& productos);
void mostrarComentariosDesde(vector<Comentario>& comentarios, string fecha);
Producto* buscarProductoPorId(vector<Producto>& productos, int id);
void adicionarProductoAlCarrito(CarritoDeCompras& carrito, Producto& producto, int cantidad);
void listarProductosDelCarrito(CarritoDeCompras& carrito);
int generarIdCarrito();

void menuUsuario(vector<Usuario>& usuarios, vector<Producto>& productos, vector<Comentario>& comentarios) {
    string correo = iniciarSesion(usuarios);
    if (correo == "") return;

    CarritoDeCompras carrito;
    carrito.idCarrito = generarIdCarrito();
    carrito.correoUsuario = correo;
    carrito.cantidadItems = 0;

    int opcion;
    do {
        cout << "\n--- MENU PRINCIPAL ---\n";
        cout << "1. Ver productos con bajo stock\n";
        cout << "2. Ver comentarios desde una fecha\n";
        cout << "3. Agregar producto al carrito\n";
        cout << "4. Ver carrito\n";
        cout << "5. Salir\n";
        cout << "Opcion: ";
        cin >> opcion;

        if (opcion == 1)
            listarProductosBajoStock(productos);
        else if (opcion == 2) {
            string fecha;
            cout << "Ingrese fecha (YYYY-MM-DD): ";
            cin >> fecha;
            mostrarComentariosDesde(comentarios, fecha);
        } else if (opcion == 3) {
            int id, cantidad;
            cout << "ID del producto: ";
            cin >> id;
            Producto* p = buscarProductoPorId(productos, id);
            if (p) {
                cout << "Cantidad: ";
                cin >> cantidad;
                adicionarProductoAlCarrito(carrito, *p, cantidad);
            } else {
                cout << "Producto no encontrado.\n";
            }
        } else if (opcion == 4)
            listarProductosDelCarrito(carrito);

    } while (opcion != 5);
}

int main() {
    vector<Usuario> usuarios = inicializarUsuarios();
    vector<Producto> productos = inicializarProductos();
    vector<Comentario> comentarios = inicializarComentarios();

    menuUsuario(usuarios, productos, comentarios);
    return 0;
}
