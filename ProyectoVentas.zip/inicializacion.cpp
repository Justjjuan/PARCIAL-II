#include "estructuras.h"
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

string upperStr(string texto) {
    transform(texto.begin(), texto.end(), texto.begin(), ::toupper);
    return texto;
}

bool fechaMayorOIgual(string f1, string f2) {
    return f1 >= f2;
}

vector<Usuario> inicializarUsuarios() {
    return {
        {"Juan Perez", "juan@gmail.com", "1234"},
        {"Maria Gomez", "maria@gmail.com", "abcd"},
        {"Carlos Ruiz", "carlos@gmail.com", "5678"}
    };
}

vector<Producto> inicializarProductos() {
    return {
        {1, "Laptop Lenovo", 3200000, 5, "2024-09-01"},
        {2, "Mouse Logitech", 85000, 2, "2024-09-05"},
        {3, "Teclado Redragon", 150000, 1, "2024-09-10"}
    };
}

vector<Comentario> inicializarComentarios() {
    return {
        {"Juan", "Buen producto", "2024-09-12"},
        {"Maria", "Excelente calidad", "2024-09-15"},
        {"Carlos", "Entrega rápida", "2024-09-20"}
    };
}
