#include "estructuras.h"
#include <iostream>
#include <vector>
using namespace std;

bool fechaMayorOIgual(string f1, string f2);

void listarProductosBajoStock(vector<Producto>& productos) {
    cout << "\n--- Productos con bajo stock (<=2) ---\n";
    for (auto& p : productos) {
        if (p.cantidadDisponible <= 2) {
            cout << "ID: " << p.idProducto << " | " << p.nombre
                 << " | Cantidad: " << p.cantidadDisponible << endl;
        }
    }
}

void mostrarComentariosDesde(vector<Comentario>& comentarios, string fecha) {
    cout << "\n--- Comentarios desde " << fecha << " ---\n";
    for (auto& c : comentarios) {
        if (fechaMayorOIgual(c.fecha, fecha)) {
            cout << c.fecha << " - " << c.autor << ": " << c.contenido << endl;
        }
    }
}

Producto* buscarProductoPorId(vector<Producto>& productos, int id) {
    for (auto& p : productos) {
        if (p.idProducto == id)
            return &p;
    }
    return nullptr;
}
