#include "estructuras.h"
#include <iostream>
#include <vector>
using namespace std;

string iniciarSesion(vector<Usuario>& usuarios) {
    string correo, clave;
    cout << "Correo: ";
    cin >> correo;
    cout << "Clave: ";
    cin >> clave;

    for (auto& u : usuarios) {
        if (u.correo == correo && u.clave == clave) {
            cout << "Inicio de sesion exitoso. Bienvenido, " << u.nombre << "!
";
            return u.correo;
        }
    }
    cout << "Correo o clave incorrectos.
";
    return "";
}

void listarUsuarios(vector<Usuario>& usuarios) {
    cout << "\n--- Lista de Usuarios ---\n";
    for (auto& u : usuarios)
        cout << "Nombre: " << u.nombre << " | Correo: " << u.correo << endl;
}
